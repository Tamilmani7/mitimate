let vehicleProgress = 0;
let trackingInterval;

function initTracker() {
  const params = new URLSearchParams(window.location.search);
  const orderId = params.get('order');
  if (orderId) {
    document.getElementById('orderIdInput').value = orderId;
    trackOrder();
  }
}

function trackOrder() {
  const input = document.getElementById('orderIdInput').value.trim();
  if (!input) return;
  document.getElementById('displayOrderId').textContent = input;
  document.getElementById('trackerResult').style.display = 'block';
  document.getElementById('trackerResult').scrollIntoView({ behavior: 'smooth' });

  const stored = localStorage.getItem('lastOrder');
  if (stored) {
    const order = JSON.parse(stored);
    populateOrderDetails(order);
  } else {
    populateDemoOrder();
  }
  startVehicleAnimation();
  startEtaCountdown();
}

function demoTrack() {
  document.getElementById('orderIdInput').value = 'MM-2025-4821';
  trackOrder();
}

function populateDemoOrder() {
  const demoItems = [
    { name: 'Organic Tomatoes', emoji: '🍅', qty: 2, price: 35 },
    { name: 'Fresh Spinach', emoji: '🌿', qty: 1, price: 25 },
    { name: 'A2 Cow Milk', emoji: '🥛', qty: 1, price: 70 }
  ];
  renderOrderPreview(demoItems);
  renderOrderSummary(demoItems);
}

function populateOrderDetails(order) {
  const items = order.items || [];
  const preview = document.getElementById('orderItemsPreview');
  if (preview) {
    preview.innerHTML = items.map(i => `<span class="preview-chip">${i.emoji} ${i.name} ×${i.qty}</span>`).join('');
  }
  renderOrderSummary(items);
  const total = document.getElementById('trackTotalAmt');
  if (total) total.textContent = `₹${order.total || 0}`;
}

function renderOrderPreview(items) {
  const preview = document.getElementById('orderItemsPreview');
  if (preview) {
    preview.innerHTML = items.map(i => `<span class="preview-chip">${i.emoji} ${i.name} ×${i.qty}</span>`).join('');
  }
}

function renderOrderSummary(items) {
  const summary = document.getElementById('trackOrderSummary');
  if (!summary) return;
  const total = items.reduce((s, i) => s + i.price * i.qty, 0);
  summary.innerHTML = items.map(i => `
    <div class="track-summary-row">
      <span>${i.emoji} ${i.name} ×${i.qty}</span>
      <span>₹${i.price * i.qty}</span>
    </div>
  `).join('');
  const totalEl = document.getElementById('trackTotalAmt');
  if (totalEl) totalEl.textContent = `₹${total + 40}`;
}

function startVehicleAnimation() {
  const vehicle = document.getElementById('deliveryVehicle');
  if (!vehicle) return;
  vehicleProgress = 0;

  const positions = [
    { left: '18%', top: '35%' },
    { left: '30%', top: '45%' },
    { left: '45%', top: '50%' },
    { left: '60%', top: '55%' },
    { left: '72%', top: '62%' }
  ];

  let posIdx = 1;
  const applyPos = () => {
    const p = positions[posIdx];
    vehicle.style.left = p.left;
    vehicle.style.top = p.top;
    posIdx = (posIdx + 1) % positions.length;
  };

  vehicle.style.left = positions[0].left;
  vehicle.style.top = positions[0].top;

  clearInterval(trackingInterval);
  trackingInterval = setInterval(applyPos, 4000);

  updateDistanceLabel(positions, posIdx);
}

function updateDistanceLabel(positions, idx) {
  const label = document.getElementById('distanceLabel');
  if (!label) return;
  const distances = ['3.2 km away', '2.8 km away', '2.1 km away', '1.4 km away', '0.6 km away'];
  label.textContent = distances[Math.min(idx, distances.length - 1)];
}

let etaMinutes = 54;
let etaInterval;

function startEtaCountdown() {
  clearInterval(etaInterval);
  etaMinutes = 54;
  updateEtaDisplay();
  etaInterval = setInterval(() => {
    etaMinutes = Math.max(0, etaMinutes - 1);
    updateEtaDisplay();
    const progress = Math.round(((54 - etaMinutes) / 54) * 100);
    const bar = document.getElementById('etaProgress');
    if (bar) bar.style.width = (40 + progress * 0.6) + '%';
    const note = document.querySelector('.eta-note');
    if (note) note.textContent = `Your order is ${Math.min(100, 40 + Math.round(progress * 0.6))}% of the way there!`;
    if (etaMinutes === 0) {
      clearInterval(etaInterval);
      const badge = document.getElementById('statusBadge');
      if (badge) { badge.textContent = 'Delivered ✅'; badge.style.background = '#d1fae5'; }
    }
  }, 60000);
}

function updateEtaDisplay() {
  const countdown = document.getElementById('etaCountdown');
  const timeEl = document.getElementById('etaTime');
  if (countdown) {
    if (etaMinutes >= 60) {
      const h = Math.floor(etaMinutes / 60);
      const m = etaMinutes % 60;
      countdown.textContent = `${h}h ${m}m`;
    } else {
      countdown.textContent = `${etaMinutes} min`;
    }
  }
  if (timeEl) {
    const now = new Date();
    now.setMinutes(now.getMinutes() + etaMinutes);
    timeEl.textContent = `by ${now.getHours() % 12 || 12}:${String(now.getMinutes()).padStart(2, '0')} ${now.getHours() >= 12 ? 'PM' : 'AM'}`;
  }
}

function callAgent() {
  alert('📞 Connecting to Murugan S. — +91 98765 43210\n\n(In production this would initiate a call)');
}

window.addEventListener('DOMContentLoaded', initTracker);
