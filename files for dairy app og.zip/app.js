let cart = [];
let currentCategory = 'all';
let currentPage = 1;
const PAGE_SIZE = 40;
let displayedProducts = [];
let filteredProducts = [...ALL_PRODUCTS];
let bannerIndex = 0;
let bannerTimer;

function init() {
  renderBannerDots();
  startBannerAuto();
  detectLocation();
  startRealtimeTicker();
  renderProducts();
  loadQuickUpdateDropdown();
}

function renderBannerDots() {
  const container = document.getElementById('bannerDots');
  if (!container) return;
  container.innerHTML = '';
  const slides = document.querySelectorAll('.banner-slide');
  slides.forEach((_, i) => {
    const dot = document.createElement('div');
    dot.className = 'banner-dot' + (i === 0 ? ' active' : '');
    dot.onclick = () => goToBanner(i);
    container.appendChild(dot);
  });
}

function goToBanner(i) {
  bannerIndex = i;
  const track = document.getElementById('bannerTrack');
  if (track) track.style.transform = `translateX(-${bannerIndex * 100}%)`;
  document.querySelectorAll('.banner-dot').forEach((d, j) => {
    d.classList.toggle('active', j === bannerIndex);
  });
}

function changeBanner(dir) {
  const slides = document.querySelectorAll('.banner-slide').length;
  bannerIndex = (bannerIndex + dir + slides) % slides;
  goToBanner(bannerIndex);
  resetBannerAuto();
}

function startBannerAuto() {
  bannerTimer = setInterval(() => changeBanner(1), 5000);
}

function resetBannerAuto() {
  clearInterval(bannerTimer);
  startBannerAuto();
}

function detectLocation() {
  const el = document.getElementById('locationText');
  if (!el) return;
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      () => { el.textContent = 'Ambattur, Chennai'; },
      () => { el.textContent = 'Ambattur, Chennai'; }
    );
  } else {
    el.textContent = 'Ambattur, Chennai';
  }
}

const TICKER_MSGS = [
  '🍅 Tomatoes — ₹35/kg · Updated 2 min ago',
  '🥛 A2 Cow Milk — ₹70/litre · Fresh batch arrived',
  '🌀 Manapparai Murukku — Only 30 packs left!',
  '🏺 Clay Pots — New stock from Kancheepuram artisans',
  '🥥 Tender Coconut — ₹35/piece · Peak summer stock',
  '🧄 Garlic — Price drop today ₹80/250g',
  '🍯 Forest Honey — Limited quantity · Order fast!',
  '🥭 Alphonso Mango — Season begins! ₹120/kg',
  '🌿 Organic Curry Leaves — Free with orders above ₹299',
  '💐 Fresh Vazhaipoo — Harvested this morning'
];
let tickerIdx = 0;

function startRealtimeTicker() {
  const el = document.getElementById('realtimeTicker');
  if (!el) return;
  el.textContent = TICKER_MSGS[0];
  setInterval(() => {
    tickerIdx = (tickerIdx + 1) % TICKER_MSGS.length;
    el.style.opacity = '0';
    setTimeout(() => {
      el.textContent = TICKER_MSGS[tickerIdx];
      el.style.opacity = '1';
    }, 300);
  }, 3500);
}

function renderProducts() {
  const grid = document.getElementById('productsGrid');
  if (!grid) return;
  const start = 0;
  const end = currentPage * PAGE_SIZE;
  displayedProducts = filteredProducts.slice(start, end);
  grid.innerHTML = displayedProducts.map(p => productCard(p)).join('');
  document.getElementById('productCount').textContent = `${filteredProducts.length} products`;
  const btn = document.getElementById('loadMoreBtn');
  if (btn) btn.style.display = filteredProducts.length > end ? 'block' : 'none';
}

function productCard(p) {
  const stockStatus = p.stock > 50 ? 'in-stock' : p.stock > 10 ? 'low-stock' : 'out-of-stock';
  const stockLabel = p.stock > 50 ? 'In Stock' : p.stock > 10 ? 'Low Stock' : 'Out of Stock';
  const stars = '★'.repeat(Math.floor(p.rating)) + (p.rating % 1 >= 0.5 ? '½' : '');
  return `
    <div class="product-card">
      <div class="product-img" style="background:${p.bg}">
        ${p.emoji}
        <span class="stock-badge ${stockStatus}">${stockLabel}</span>
      </div>
      <div class="product-info">
        <div class="product-name">${p.name}</div>
        <div class="product-seller">👨‍🌾 ${p.seller}, ${p.village}</div>
        <div class="product-distance">📍 ${p.distance} km · 🕒 ${p.deliveryTime}</div>
        <div class="product-rating">${stars} ${p.rating}</div>
      </div>
      <div class="product-footer">
        <div>
          <div class="product-price">₹${p.price}</div>
          <div class="product-unit">${p.unit}</div>
        </div>
        <button class="add-btn" onclick="addToCart(${p.id})" ${p.stock === 0 ? 'disabled' : ''}>
          ${p.stock === 0 ? 'Sold Out' : '+ Add'}
        </button>
      </div>
    </div>
  `;
}

function filterByCategory(cat, el) {
  currentCategory = cat;
  currentPage = 1;
  document.querySelectorAll('.cat-chip').forEach(c => c.classList.remove('active'));
  if (el) el.classList.add('active');
  applyFilters();
  const titles = {
    all: 'All Farm Products',
    vegetables: '🥦 Fresh Vegetables',
    fruits: '🍎 Fresh Fruits',
    snacks: '🫘 Village Snacks',
    dairy: '🥛 Dairy Products',
    earthenware: '🏺 Earthenware & Pottery'
  };
  document.getElementById('sectionTitle').textContent = titles[cat] || 'Products';
}

function scrollToCategory(cat) {
  const chip = document.getElementById('cat-' + cat);
  if (chip) chip.click();
  document.querySelector('.categories-strip').scrollIntoView({ behavior: 'smooth' });
}

function filterProducts() {
  currentPage = 1;
  applyFilters();
}

function applyFilters() {
  const query = (document.getElementById('searchInput')?.value || '').toLowerCase();
  filteredProducts = ALL_PRODUCTS.filter(p => {
    const matchCat = currentCategory === 'all' || p.category === currentCategory;
    const matchSearch = !query || p.name.toLowerCase().includes(query) || p.seller.toLowerCase().includes(query) || p.village.toLowerCase().includes(query);
    return matchCat && matchSearch;
  });
  renderProducts();
}

function sortProducts(val) {
  if (val === 'price-asc') filteredProducts.sort((a, b) => a.price - b.price);
  else if (val === 'price-desc') filteredProducts.sort((a, b) => b.price - a.price);
  else if (val === 'rating') filteredProducts.sort((a, b) => b.rating - a.rating);
  else if (val === 'distance') filteredProducts.sort((a, b) => a.distance - b.distance);
  else filteredProducts = [...ALL_PRODUCTS].filter(p => currentCategory === 'all' || p.category === currentCategory);
  renderProducts();
}

function loadMore() {
  currentPage++;
  renderProducts();
}

function addToCart(id) {
  const product = ALL_PRODUCTS.find(p => p.id === id);
  if (!product) return;
  const existing = cart.find(i => i.id === id);
  if (existing) {
    existing.qty++;
  } else {
    cart.push({ ...product, qty: 1 });
  }
  updateCartUI();
  showToast(`✅ ${product.emoji} ${product.name} added to cart!`);
}

function updateCartUI() {
  const count = cart.reduce((s, i) => s + i.qty, 0);
  document.getElementById('cartCount').textContent = count;

  const itemsEl = document.getElementById('cartItems');
  const footerEl = document.getElementById('cartFooter');

  if (cart.length === 0) {
    itemsEl.innerHTML = '<div class="empty-cart">Your cart is empty.<br/>Add products to get started!</div>';
    footerEl.style.display = 'none';
    return;
  }

  itemsEl.innerHTML = cart.map(item => `
    <div class="cart-item">
      <div class="cart-item-emoji">${item.emoji}</div>
      <div class="cart-item-info">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-price">₹${item.price} ${item.unit}</div>
      </div>
      <div class="cart-item-controls">
        <div class="qty-btn" onclick="changeQty(${item.id},-1)">−</div>
        <div class="qty-display">${item.qty}</div>
        <div class="qty-btn" onclick="changeQty(${item.id},1)">+</div>
      </div>
    </div>
  `).join('');

  footerEl.style.display = 'block';
  const subtotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const delivery = subtotal > 299 ? 0 : 40;
  const total = subtotal + delivery;
  const maxDist = Math.max(...cart.map(i => i.distance));
  const estTime = maxDist < 5 ? '30-45 min' : maxDist < 10 ? '1-2 hrs' : '2-4 hrs';

  document.getElementById('cartSubtotal').textContent = `₹${subtotal}`;
  document.getElementById('deliveryFee').textContent = delivery === 0 ? 'FREE' : `₹${delivery}`;
  document.getElementById('estDelivery').textContent = estTime;
  document.getElementById('cartTotal').textContent = `₹${total}`;
}

function changeQty(id, delta) {
  const item = cart.find(i => i.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) cart = cart.filter(i => i.id !== id);
  updateCartUI();
}

function toggleCart() {
  const panel = document.getElementById('cartPanel');
  const overlay = document.getElementById('cartOverlay');
  panel.classList.toggle('open');
  overlay.classList.toggle('show');
}

function checkout() {
  const total = cart.reduce((s, i) => s + i.price * i.qty, 0) + 40;
  const orderId = 'MM-2025-' + Math.floor(1000 + Math.random() * 9000);
  localStorage.setItem('lastOrder', JSON.stringify({ id: orderId, items: cart, total }));
  showToast('🎉 Order placed! Redirecting to tracking…');
  setTimeout(() => { window.location.href = `tracker.html?order=${orderId}`; }, 1500);
}

function showToast(msg) {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2800);
}

function loadQuickUpdateDropdown() {}

window.addEventListener('DOMContentLoaded', init);
