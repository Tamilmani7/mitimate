let sellerProducts = ALL_PRODUCTS.filter((_, i) => i < 50);
let inventoryFilter = '';
let inventoryCategory = 'all';

const MOCK_ORDERS = [
  { id: 'MM-2025-4821', items: 'Tomatoes × 2, Spinach × 1', addr: 'Anna Nagar, Chennai', amt: 95, status: 'out', emoji: '🍅' },
  { id: 'MM-2025-4820', items: 'A2 Milk × 3, Ghee × 1', addr: 'Velachery, Chennai', amt: 810, status: 'packing', emoji: '🥛' },
  { id: 'MM-2025-4819', items: 'Murukku × 2, Thattai × 1', addr: 'Tambaram, Chennai', amt: 340, status: 'new', emoji: '🌀' },
  { id: 'MM-2025-4818', items: 'Clay Pot × 1, Kullar × 12', addr: 'Porur, Chennai', amt: 170, status: 'delivered', emoji: '🏺' },
  { id: 'MM-2025-4817', items: 'Coconut × 5, Tender × 3', addr: 'Guindy, Chennai', amt: 230, status: 'delivered', emoji: '🥥' }
];

function initSeller() {
  renderInventory();
  renderOrders();
  drawSalesChart();
  updateStats();
  populateQuickSelect();
  startLiveUpdates();
}

function renderInventory() {
  const body = document.getElementById('inventoryBody');
  if (!body) return;
  const filtered = sellerProducts.filter(p => {
    const matchSearch = !inventoryFilter || p.name.toLowerCase().includes(inventoryFilter.toLowerCase());
    const matchCat = inventoryCategory === 'all' || p.category === inventoryCategory;
    return matchSearch && matchCat;
  });
  body.innerHTML = filtered.map(p => {
    const stockClass = p.stock > 80 ? 'high' : p.stock > 20 ? 'medium' : 'low';
    return `
      <tr>
        <td><span style="font-size:18px;margin-right:8px">${p.emoji}</span>${p.name}</td>
        <td style="text-transform:capitalize">${p.category}</td>
        <td>₹${p.price} <small style="color:#999">${p.unit}</small></td>
        <td><span class="stock-pill ${stockClass}">${p.stock} units</span></td>
        <td><span class="stock-pill ${stockClass}">${p.stock > 80 ? 'Available' : p.stock > 20 ? 'Limited' : 'Low'}</span></td>
        <td>
          <button class="action-btn" onclick="editProduct(${p.id})">✏️ Edit</button>
          <button class="action-btn" onclick="removeProduct(${p.id})">🗑️</button>
        </td>
      </tr>
    `;
  }).join('');
}

function filterInventory(val) {
  inventoryFilter = val;
  renderInventory();
}

function filterInventoryByCategory(val) {
  inventoryCategory = val;
  renderInventory();
}

function renderOrders() {
  const list = document.getElementById('ordersList');
  if (!list) return;
  const statusMap = {
    new: { label: 'New Order', cls: 'status-new' },
    packing: { label: 'Packing', cls: 'status-packing' },
    out: { label: 'Out for Delivery', cls: 'status-out' },
    delivered: { label: 'Delivered', cls: 'status-delivered' }
  };
  list.innerHTML = MOCK_ORDERS.map(o => {
    const s = statusMap[o.status];
    return `
      <div class="order-row">
        <div class="order-row-emoji">${o.emoji}</div>
        <div class="order-row-info">
          <div class="order-row-id">${o.id}</div>
          <div class="order-row-items">${o.items}</div>
          <div class="order-row-addr">📍 ${o.addr}</div>
        </div>
        <div style="text-align:right">
          <div class="order-row-amt">₹${o.amt}</div>
          <span class="order-status ${s.cls}">${s.label}</span>
        </div>
      </div>
    `;
  }).join('');
}

function drawSalesChart() {
  const canvas = document.getElementById('salesChart');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const data = [1200, 1850, 1400, 2100, 1750, 2400, 1980];
  const maxVal = Math.max(...data);
  const W = canvas.width;
  const H = canvas.height;
  const pad = { top: 20, right: 20, bottom: 30, left: 40 };
  const chartW = W - pad.left - pad.right;
  const chartH = H - pad.top - pad.bottom;

  ctx.clearRect(0, 0, W, H);
  ctx.fillStyle = '#f4f1eb';
  ctx.fillRect(0, 0, W, H);

  const barW = (chartW / days.length) * 0.6;
  const gap = chartW / days.length;

  data.forEach((val, i) => {
    const barH = (val / maxVal) * chartH;
    const x = pad.left + i * gap + (gap - barW) / 2;
    const y = pad.top + chartH - barH;
    const grad = ctx.createLinearGradient(0, y, 0, pad.top + chartH);
    grad.addColorStop(0, '#2d6a1f');
    grad.addColorStop(1, '#a8d08d');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.roundRect(x, y, barW, barH, 4);
    ctx.fill();

    ctx.fillStyle = '#7a7a72';
    ctx.font = '10px DM Sans, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(days[i], pad.left + i * gap + gap / 2, H - 8);

    ctx.fillStyle = '#1a3a0a';
    ctx.font = 'bold 9px DM Sans, sans-serif';
    ctx.fillText('₹' + (val / 1000).toFixed(1) + 'k', pad.left + i * gap + gap / 2, y - 4);
  });
}

function updateStats() {
  const orders = MOCK_ORDERS.length;
  const revenue = MOCK_ORDERS.reduce((s, o) => s + o.amt, 0);
  const pending = MOCK_ORDERS.filter(o => o.status !== 'delivered').length;

  animateCount('totalOrders', 0, orders, 800);
  animateCount('totalRevenue', 0, revenue, 1000, '₹');
  animateCount('pendingDeliveries', 0, pending, 600);
}

function animateCount(id, from, to, duration, prefix = '') {
  const el = document.getElementById(id);
  if (!el) return;
  const start = performance.now();
  function step(now) {
    const elapsed = now - start;
    const progress = Math.min(elapsed / duration, 1);
    const val = Math.floor(from + (to - from) * progress);
    el.textContent = prefix + val;
    if (progress < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

function populateQuickSelect() {
  const sel = document.getElementById('quickProduct');
  if (!sel) return;
  sel.innerHTML = sellerProducts.slice(0, 20).map(p =>
    `<option value="${p.id}">${p.emoji} ${p.name}</option>`
  ).join('');
}

function quickUpdate() {
  const prodId = parseInt(document.getElementById('quickProduct').value);
  const newStock = parseInt(document.getElementById('quickStock').value);
  const newPrice = parseInt(document.getElementById('quickPrice').value);
  const p = sellerProducts.find(x => x.id === prodId);
  if (!p) return;
  if (!isNaN(newStock)) p.stock = newStock;
  if (!isNaN(newPrice)) p.price = newPrice;
  renderInventory();
  showSellerToast('✅ Product updated successfully!');
  document.getElementById('quickStock').value = '';
  document.getElementById('quickPrice').value = '';
}

function editProduct(id) {
  showSellerToast('✏️ Edit feature — connect to your database API');
}

function removeProduct(id) {
  sellerProducts = sellerProducts.filter(p => p.id !== id);
  renderInventory();
  showSellerToast('🗑️ Product removed from inventory');
}

function openAddProduct() {
  document.getElementById('addProductModal').style.display = 'flex';
}

function closeAddProduct() {
  document.getElementById('addProductModal').style.display = 'none';
}

function addSellerProduct() {
  const name = document.getElementById('newName').value;
  const category = document.getElementById('newCategory').value;
  const price = parseInt(document.getElementById('newPrice').value) || 0;
  const unit = document.getElementById('newUnit').value || 'per unit';
  const stock = parseInt(document.getElementById('newStock').value) || 0;
  const emoji = document.getElementById('newEmoji').value || '📦';
  if (!name) { showSellerToast('⚠️ Please enter a product name'); return; }
  const newProd = {
    id: Date.now(),
    name, category, price, unit, stock, emoji,
    rating: 4.5, seller: 'Rajan Kumar', village: 'Kancheepuram',
    distance: 3.2, bg: 'linear-gradient(135deg,#e8f5e0,#c8e6b0)',
    deliveryTime: '30-45 min'
  };
  sellerProducts.unshift(newProd);
  renderInventory();
  closeAddProduct();
  showSellerToast(`✅ ${emoji} ${name} added to inventory!`);
}

function startLiveUpdates() {
  setInterval(() => {
    const idx = Math.floor(Math.random() * sellerProducts.length);
    const change = Math.floor(Math.random() * 6) - 2;
    sellerProducts[idx].stock = Math.max(0, sellerProducts[idx].stock + change);
    renderInventory();
  }, 8000);
}

let sellerToastTimer;
function showSellerToast(msg) {
  let toast = document.getElementById('sellerToast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'sellerToast';
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(sellerToastTimer);
  sellerToastTimer = setTimeout(() => toast.classList.remove('show'), 2800);
}

window.addEventListener('DOMContentLoaded', initSeller);
